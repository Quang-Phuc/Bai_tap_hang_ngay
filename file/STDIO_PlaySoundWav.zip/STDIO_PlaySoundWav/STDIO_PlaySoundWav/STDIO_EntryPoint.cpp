/*
Author: Tai Du Phat
hcmc - oct 2, 2014
www.stdio.vn

Please keep this comment in your source code!
*/

#ifndef UNICODE
#define UNICODE
#endif

#include <stdio.h>
#include "Windows.h"

#pragma comment(lib, "winmm.lib")

void main()
{
	bool isPlay = PlaySound(L"STDIO_SOUND_LOGO.wav", NULL, SND_FILENAME);

	if (isPlay)
	{
		printf("This sound can be played");
	}
}